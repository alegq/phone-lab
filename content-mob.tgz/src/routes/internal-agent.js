const { randomUUID } = require('crypto');
const { assertInternalToken, handleAuthError } = require('../auth');
const {
  getAllowlist,
  putAllowlist,
  storeGscSnapshot,
  getGscMetrics,
  getDraft,
  draftStructure,
  draftContent,
  draftSeo,
  syncSeoOpportunities,
  listSeoOpportunities,
} = require('../store');

function withToken(req, res, expectedToken, handler) {
  try {
    assertInternalToken(req.get('x-internal-service-token'), expectedToken);
    return handler();
  } catch (err) {
    return handleAuthError(res, err);
  }
}

function registerInternalAgentRoutes(app, store, expectedToken) {
  const base = '/public/api/content/internal/agent';

  app.get(`${base}/protected-keywords`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ keywords: [] });
    });
  });

  app.get(`${base}/published-posts-seo`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ items: [] });
    });
  });

  app.get(`${base}/content-clusters`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json([]);
    });
  });

  app.get(`${base}/template-draft/:slug/structure`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const draft = getDraft(store, req.params.slug);
      if (!draft) {
        return res.status(404).json({ message: 'Draft not found', statusCode: 404 });
      }
      res.json(draftStructure(draft));
    });
  });

  app.get(`${base}/template-draft/:slug/content`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const draft = getDraft(store, req.params.slug);
      if (!draft) {
        return res.status(404).json({ message: 'Draft not found', statusCode: 404 });
      }
      res.json(draftContent(draft));
    });
  });

  app.get(`${base}/template-draft/:slug/seo`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const draft = getDraft(store, req.params.slug);
      if (!draft) {
        return res.status(404).json({ message: 'Draft not found', statusCode: 404 });
      }
      res.json(draftSeo(draft));
    });
  });

  app.get(`${base}/published-posts`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ items: store.publishedPosts });
    });
  });

  app.get(`${base}/published-keywords`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ items: [] });
    });
  });

  app.get(`${base}/seo-opportunities`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json(
        listSeoOpportunities(store, {
          locale: req.query.locale,
          siteUrl: req.query.siteUrl,
          source: req.query.source,
          status: req.query.status,
        }),
      );
    });
  });

  app.get(`${base}/competitor-allowlist`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const siteUrl = req.query.siteUrl;
      if (!siteUrl) {
        return res.status(400).json({ message: 'siteUrl is required', statusCode: 400 });
      }
      res.json(getAllowlist(store, String(siteUrl)));
    });
  });

  app.get(`${base}/post/:slug/for-optimizer`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const slug = req.params.slug;
      res.json({
        slug,
        title: { en: 'Stub post for optimizer' },
        seo: {
          metaTitle: 'Stub',
          metaDescription: 'Stub description',
          targetKeyword: 'stub keyword',
        },
        heroImageUrl: null,
        url: `https://ezrababait.co.il/blogs/${slug}`,
      });
    });
  });

  app.get(`${base}/gsc/metrics`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const siteUrl = req.query.siteUrl;
      if (!siteUrl) {
        return res.status(400).json({ message: 'siteUrl is required', statusCode: 400 });
      }
      res.json(
        getGscMetrics(store, {
          siteUrl: String(siteUrl),
          locale: req.query.locale ? String(req.query.locale) : undefined,
        }),
      );
    });
  });

  app.post(`${base}/link-draft-to-run`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const { draftSlug, runId } = req.body ?? {};
      const draft = getDraft(store, draftSlug);
      if (draft) {
        draft.runId = runId;
      }
      res.json({
        draftId: draft?.draftId ?? randomUUID(),
        draftSlug: draftSlug ?? 'unknown',
      });
    });
  });

  app.post(`${base}/materialize-draft`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const draftSlug = req.body?.draftSlug ?? 'template-builder-test';
      const draft = getDraft(store, draftSlug);
      res.json({
        draftSlug,
        draftId: draft?.draftId ?? randomUUID(),
      });
    });
  });

  app.post(`${base}/capture-approval-snapshot`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ draftId: req.body?.draftId ?? randomUUID(), captured: true });
    });
  });

  app.post(`${base}/apply-approval-snapshot`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ ok: true });
    });
  });

  app.post(`${base}/publish-draft`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const draftSlug = req.body?.draftSlug ?? 'template-builder-test';
      const postSlug = `${draftSlug}-published`;
      res.json({
        draftSlug,
        postSlug,
        publishedAt: new Date().toISOString(),
      });
    });
  });

  app.post(`${base}/generate-agent-run-image`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ storageUrl: 'https://example.com/stub.png' });
    });
  });

  app.post(`${base}/supersede-draft-by-run`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({ ok: true });
    });
  });

  app.post(`${base}/sync-seo-opportunities`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json(syncSeoOpportunities(store, req.body ?? {}));
    });
  });

  app.post(`${base}/clone-post-to-draft`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const postSlug = req.body?.postSlug ?? 'stub-post';
      const draftSlug = `${postSlug}-draft`;
      res.json({
        draftSlug,
        draftId: randomUUID(),
        publishedPostSlug: postSlug,
      });
    });
  });

  app.post(`${base}/apply-on-page-recommendations`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      const draftSlug = req.body?.draftSlug ?? 'stub-draft';
      const recs = Array.isArray(req.body?.recommendations) ? req.body.recommendations : [];
      res.json({
        draftSlug,
        draftId: randomUUID(),
        appliedCount: recs.length,
        skippedCount: 0,
        appliedIds: recs.map((r) => r.id).filter(Boolean),
      });
    });
  });

  app.post(`${base}/gsc/snapshots`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json(storeGscSnapshot(store, req.body ?? {}));
    });
  });

  app.patch(`${base}/seo-opportunities/:opportunityId/in-progress`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({
        id: req.params.opportunityId,
        status: 'in_progress',
        blogRunId: req.body?.blogRunId ?? null,
      });
    });
  });

  app.patch(`${base}/seo-opportunities/:opportunityId/serp-snapshot`, (req, res) => {
    withToken(req, res, expectedToken, () => {
      res.json({
        id: req.params.opportunityId,
        serpSnapshotJson: req.body?.serpSnapshotJson ?? {},
        suggestedSerpVerdict: req.body?.suggestedSerpVerdict ?? null,
      });
    });
  });
}

module.exports = { registerInternalAgentRoutes };
