const { randomUUID } = require('crypto');

function createStore() {
  return {
    allowlists: new Map(),
    gscSnapshots: new Map(),
    seoOpportunities: new Map(),
    drafts: new Map(),
    publishedPosts: [],
    snapshots: new Map(),
  };
}

function allowlistKey(siteUrl) {
  return siteUrl.replace(/\/$/, '') || siteUrl;
}

function gscKey(siteUrl, locale = '') {
  return `${allowlistKey(siteUrl)}|${locale}`;
}

function getAllowlist(store, siteUrl) {
  const key = allowlistKey(siteUrl);
  const entry = store.allowlists.get(key);
  if (!entry) {
    return {
      siteUrl: key,
      domains: [],
      updatedBy: null,
      updatedAt: new Date().toISOString(),
    };
  }
  return { siteUrl: key, ...entry };
}

function putAllowlist(store, { siteUrl, domains, updatedBy }) {
  const key = allowlistKey(siteUrl);
  const entry = {
    domains: Array.isArray(domains) ? domains : [],
    updatedBy: updatedBy ?? null,
    updatedAt: new Date().toISOString(),
  };
  store.allowlists.set(key, entry);
  return { siteUrl: key, ...entry };
}

function storeGscSnapshot(store, body) {
  const key = gscKey(body.siteUrl, body.locale ?? '');
  const snapshotId = randomUUID();
  const snapshot = {
    snapshotId,
    siteUrl: body.siteUrl,
    gscProperty: body.gscProperty,
    locale: body.locale ?? null,
    snapshotDate: body.snapshotDate,
    rows: Array.isArray(body.rows) ? body.rows : [],
    sourceRunId: body.sourceRunId ?? null,
    storedAt: new Date().toISOString(),
  };
  store.gscSnapshots.set(key, snapshot);
  store.snapshots.set(snapshotId, snapshot);
  return { snapshotId };
}

function getGscMetrics(store, { siteUrl, locale }) {
  const key = gscKey(siteUrl, locale ?? '');
  const snapshot = store.gscSnapshots.get(key);
  if (!snapshot) {
    return {
      siteUrl,
      snapshotDate: null,
      metrics: [],
    };
  }
  const metrics = snapshot.rows.map((row) => ({
    keyword: row.query,
    impressions: row.impressions ?? 0,
    ctr: row.ctr ?? 0,
    position: row.position ?? 0,
    clicks: row.clicks ?? 0,
    page: row.page,
  }));
  return {
    siteUrl: snapshot.siteUrl,
    snapshotDate: snapshot.snapshotDate,
    metrics,
  };
}

function getDraft(store, slug) {
  return store.drafts.get(slug) ?? null;
}

function draftStructure(draft) {
  return {
    draftId: draft.draftId,
    slug: draft.slug,
    title: draft.title,
    basePrompt: draft.basePrompt,
    sections: draft.sections.map((s) => ({
      id: s.id,
      sortOrder: s.sortOrder,
      templateType: s.templateType,
      promptHint: s.promptHint,
    })),
  };
}

function draftContent(draft) {
  return {
    draftId: draft.draftId,
    slug: draft.slug,
    title: draft.title,
    basePrompt: draft.basePrompt,
    heroImageUrl: draft.heroImageUrl,
    sections: draft.sections,
  };
}

function draftSeo(draft) {
  return {
    draftId: draft.draftId,
    slug: draft.slug,
    title: draft.title,
    seo: draft.seo,
    publishedPostSlug: draft.publishedPostSlug,
    seoContextJson: draft.seoContextJson,
  };
}

function syncSeoOpportunities(store, body) {
  const key = `${body.siteUrl}|${body.locale}`;
  const existing = store.seoOpportunities.get(key) ?? { items: [] };
  const items = Array.isArray(body.items) ? body.items : [];
  let created = 0;
  let updated = 0;
  for (const item of items) {
    const idx = existing.items.findIndex((e) => e.id === item.id);
    if (idx >= 0) {
      existing.items[idx] = { ...existing.items[idx], ...item };
      updated += 1;
    } else {
      existing.items.push(item);
      created += 1;
    }
  }
  store.seoOpportunities.set(key, existing);
  return {
    syncedCount: items.length,
    created,
    updated,
    preserved: 0,
    ranksRecomputed: false,
  };
}

function listSeoOpportunities(store, query) {
  const key = `${query.siteUrl ?? ''}|${query.locale ?? ''}`;
  const bucket = store.seoOpportunities.get(key) ?? { items: [] };
  let items = bucket.items;
  if (query.source) {
    items = items.filter((i) => i.source === query.source);
  }
  if (query.status) {
    items = items.filter((i) => i.status === query.status);
  }
  return { items, total: items.length };
}

module.exports = {
  createStore,
  getAllowlist,
  putAllowlist,
  storeGscSnapshot,
  getGscMetrics,
  getDraft,
  draftStructure,
  draftContent,
  draftSeo,
  syncSeoOpportunities,
  listSeoOpportunities,
};
