const { randomUUID } = require('crypto');

const TEMPLATE_BUILDER_TEST_SLUG = 'template-builder-test';
const TEMPLATE_BUILDER_TEST_DRAFT_ID = 'a1111111-1111-4111-8111-111111111111';

const TEST_SECTIONS = [
  { sortOrder: 0, templateType: 'plain_text' },
  { sortOrder: 1, templateType: 'heading_text' },
  { sortOrder: 2, templateType: 'heading_image_text' },
  { sortOrder: 3, templateType: 'bulleted_heading_image_text' },
];

function emptySectionData(templateType) {
  if (templateType === 'heading_image_text' || templateType === 'bulleted_heading_image_text') {
    return {
      templateType,
      blocks: [],
      heading: 'Spring cleaning tips for pet owners',
      text: 'Regular cleaning keeps pets healthy and homes fresh.',
      imagePrompt: 'Bright living room spring cleaning with a happy dog',
    };
  }
  return { templateType, blocks: [] };
}

function buildTemplateBuilderTestDraft() {
  const sections = TEST_SECTIONS.map((s) => ({
    id: randomUUID(),
    sortOrder: s.sortOrder,
    templateType: s.templateType,
    promptHint: null,
    data: emptySectionData(s.templateType),
    generationStatus: s.templateType.includes('image') ? 'generated' : 'empty',
  }));

  return {
    draftId: TEMPLATE_BUILDER_TEST_DRAFT_ID,
    slug: TEMPLATE_BUILDER_TEST_SLUG,
    title: { en: 'Template Builder Test' },
    basePrompt: 'Write an article about effective spring cleaning for pet owners.',
    heroImageUrl: null,
    seo: null,
    publishedPostSlug: null,
    seoContextJson: null,
    sections,
    status: 'structure_draft',
    runId: null,
  };
}

function seedDrafts(store) {
  if (!store.drafts.has(TEMPLATE_BUILDER_TEST_SLUG)) {
    store.drafts.set(TEMPLATE_BUILDER_TEST_SLUG, buildTemplateBuilderTestDraft());
  }
}

module.exports = {
  TEMPLATE_BUILDER_TEST_SLUG,
  TEMPLATE_BUILDER_TEST_DRAFT_ID,
  seedDrafts,
  buildTemplateBuilderTestDraft,
};
