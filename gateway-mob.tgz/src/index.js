const path = require('path');
const express = require('express');
const cors = require('cors');
const os = require('os');
require('dotenv').config();

const app = express();
const PORT = Number(process.env.PORT) || 4000;
const HOST = process.env.HOST || '0.0.0.0';
const DEVICE_LABEL = process.env.DEVICE_LABEL || 'unknown';
const MOB_VERSION = process.env.MOB_VERSION || '0.1.0';
const SERVICE_NAME = 'api-gateway-mob';
const AGENTS_INTERNAL_URL = (
  process.env.AGENTS_INTERNAL_URL || 'http://127.0.0.1:4010'
).replace(/\/$/, '');
const AGENTS_TIMEOUT_MS = Number(process.env.AGENTS_FETCH_TIMEOUT_MS) || 5000;
const AGENTS_PING_PATH =
  process.env.AGENTS_PING_PATH || '/public/api/agents/mob/ping';
const AGENTS_PING_MODE = (process.env.AGENTS_PING_MODE || 'mob').toLowerCase();

app.set('trust proxy', true);

app.use(
  cors({
    origin: true,
    credentials: false,
    methods: ['GET', 'OPTIONS'],
  }),
);

app.use((req, res, next) => {
  const remote = req.ip || req.socket.remoteAddress || '-';
  console.log(`${new Date().toISOString()} ${req.method} ${req.path} remote=${remote}`);
  next();
});

app.use(express.static(path.join(__dirname, '..', 'public')));

function agentsPingUrl() {
  const path = AGENTS_PING_PATH.startsWith('/')
    ? AGENTS_PING_PATH
    : `/${AGENTS_PING_PATH}`;
  return `${AGENTS_INTERNAL_URL}${path}`;
}

function agentsLiveUrl() {
  return `${AGENTS_INTERNAL_URL}/public/api/agents/health/live`;
}

async function fetchAgents(url) {
  const started = Date.now();
  const response = await fetch(url, {
    signal: AbortSignal.timeout(AGENTS_TIMEOUT_MS),
  });
  const text = await response.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }
  return { response, data, latencyMs: Date.now() - started };
}

function isTimeoutError(err) {
  return err?.name === 'TimeoutError' || err?.name === 'AbortError';
}

app.get('/api/mob/info', (req, res) => {
  const host = req.get('host') || `${HOST}:${PORT}`;
  const protocol = req.protocol || 'http';
  res.json({
    service: SERVICE_NAME,
    deviceLabel: DEVICE_LABEL,
    version: MOB_VERSION,
    host: os.hostname(),
    port: PORT,
    bind: HOST,
    agentsUrl: AGENTS_INTERNAL_URL,
    demoUrl: `${protocol}://${host}/`,
    agentsPingPath: AGENTS_PING_PATH,
    agentsPingMode: AGENTS_PING_MODE,
    architecture:
      AGENTS_PING_MODE === 'prod'
        ? 'Browser → api-gateway-mob (phone-a) → api-agents prod (phone-b)'
        : 'Browser → api-gateway-mob (phone-a) → api-agents-mob (phone-b)',
  });
});

app.get('/api/mob/ping', async (req, res) => {
  const target = agentsPingUrl();
  try {
    const { response, data, latencyMs } = await fetchAgents(target);
    console.log(
      `agents_ping ok agentsUrl=${AGENTS_INTERNAL_URL} path=${AGENTS_PING_PATH} latencyMs=${latencyMs} status=${response.status}`,
    );

    const agentsOk =
      AGENTS_PING_MODE === 'prod'
        ? response.ok && data?.status === 'alive'
        : response.ok && data?.ok === true;

    const agentsPayload =
      AGENTS_PING_MODE === 'prod'
        ? { ok: agentsOk, status: data?.status, service: 'api-agents' }
        : data;

    res.status(response.ok ? 200 : response.status).json({
      ok: response.ok && agentsOk,
      service: SERVICE_NAME,
      host: os.hostname(),
      deviceLabel: DEVICE_LABEL,
      version: MOB_VERSION,
      agentsUrl: AGENTS_INTERNAL_URL,
      agentsPingPath: AGENTS_PING_PATH,
      agentsPingMode: AGENTS_PING_MODE,
      latencyMs,
      agents: agentsPayload,
    });
  } catch (err) {
    if (isTimeoutError(err)) {
      console.error(
        `agents_ping timeout agentsUrl=${AGENTS_INTERNAL_URL} timeoutMs=${AGENTS_TIMEOUT_MS}`,
      );
      return res.status(504).json({
        ok: false,
        service: SERVICE_NAME,
        error: 'agents_timeout',
        agentsUrl: AGENTS_INTERNAL_URL,
      });
    }
    console.error(`agents_ping unreachable agentsUrl=${AGENTS_INTERNAL_URL} error=${err.message}`);
    return res.status(503).json({
      ok: false,
      service: SERVICE_NAME,
      error: 'agents_unreachable',
      agentsUrl: AGENTS_INTERNAL_URL,
    });
  }
});

app.get('/api/mob/health', async (_req, res) => {
  const gateway = { ok: true, service: SERVICE_NAME, deviceLabel: DEVICE_LABEL };
  try {
    const { response, data, latencyMs } = await fetchAgents(agentsLiveUrl());
    return res.json({
      gateway,
      agents: {
        ok: response.ok && data?.status === 'alive',
        status: data?.status,
        latencyMs,
        url: agentsLiveUrl(),
      },
    });
  } catch (err) {
    const error = isTimeoutError(err) ? 'agents_timeout' : 'agents_unreachable';
    return res.json({
      gateway,
      agents: { ok: false, error, url: agentsLiveUrl() },
    });
  }
});

app.use((_req, res) => {
  res.status(404).json({ ok: false, error: 'not_found' });
});

app.listen(PORT, HOST, () => {
  console.log(
    `${SERVICE_NAME} listening on ${HOST}:${PORT} label=${DEVICE_LABEL} agents=${AGENTS_INTERNAL_URL}`,
  );
});
