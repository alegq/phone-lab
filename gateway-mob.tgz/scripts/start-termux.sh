#!/data/data/com.termux/files/usr/bin/bash
# Start api-gateway-mob from Termux (phone-a-gateway).
cd "$(dirname "$0")/.." || exit 1
exec node src/index.js
