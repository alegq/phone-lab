#!/data/data/com.termux/files/usr/bin/bash
# Start api-agents-mob from Termux (phone-b-agents).
# .env is loaded by dotenv in src/index.js — no shell export needed.
cd "$(dirname "$0")/.." || exit 1
exec node src/index.js
