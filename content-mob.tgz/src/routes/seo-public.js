const { getAllowlist, putAllowlist } = require('../store');

function registerSeoPublicRoutes(app, store) {
  app.put('/public/api/content/seo/competitor-allowlist', (req, res) => {
    const { siteUrl, domains, updatedBy } = req.body ?? {};
    if (!siteUrl) {
      return res.status(400).json({ message: 'siteUrl is required', statusCode: 400 });
    }
    const result = putAllowlist(store, { siteUrl, domains, updatedBy });
    res.json(result);
  });

  app.get('/public/api/content/seo/competitor-allowlist', (req, res) => {
    const siteUrl = req.query.siteUrl;
    if (!siteUrl) {
      return res.status(400).json({ message: 'siteUrl is required', statusCode: 400 });
    }
    res.json(getAllowlist(store, String(siteUrl)));
  });
}

module.exports = { registerSeoPublicRoutes };
