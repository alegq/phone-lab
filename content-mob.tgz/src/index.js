const express = require('express');
require('dotenv').config();

const { createStore } = require('./store');
const { seedDrafts } = require('./seed');
const { registerMobRoutes } = require('./routes/mob');
const { registerHealthRoutes } = require('./routes/health');
const { registerSeoPublicRoutes } = require('./routes/seo-public');
const { registerInternalAgentRoutes } = require('./routes/internal-agent');

const PORT = Number(process.env.PORT) || 4004;
const HOST = process.env.HOST || '0.0.0.0';
const DEVICE_LABEL = process.env.DEVICE_LABEL || 'unknown';
const MOB_VERSION = process.env.MOB_VERSION || '0.1.0';
const SERVICE_NAME = 'api-content-mob';
const INTERNAL_SERVICE_TOKEN = process.env.INTERNAL_SERVICE_TOKEN || '';

const startedAt = Date.now();
const store = createStore();
seedDrafts(store);

const app = express();
app.set('trust proxy', true);
app.use(express.json());

app.use((req, res, next) => {
  const remote = req.ip || req.socket.remoteAddress || '-';
  console.log(`${new Date().toISOString()} ${req.method} ${req.path} remote=${remote}`);
  next();
});

registerMobRoutes(app, {
  serviceName: SERVICE_NAME,
  deviceLabel: DEVICE_LABEL,
  mobVersion: MOB_VERSION,
  startedAt,
});
registerHealthRoutes(app);
registerSeoPublicRoutes(app, store);
registerInternalAgentRoutes(app, store, INTERNAL_SERVICE_TOKEN);

app.use((_req, res) => {
  res.status(404).json({ ok: false, error: 'not_found' });
});

app.listen(PORT, HOST, () => {
  console.log(
    `${SERVICE_NAME} listening on ${HOST}:${PORT} label=${DEVICE_LABEL} token=${INTERNAL_SERVICE_TOKEN ? 'set' : 'unset'}`,
  );
});
