#!/data/data/com.termux/files/usr/bin/bash
# Termux:Boot — start api-gateway-mob after device reboot (phone-a-gateway).
# Installed via: bash scripts/install-boot.sh
# Logs: ~/phone-lab/logs/gateway-mob.log

NODE="/data/data/com.termux/files/usr/bin/node"
PKG_DIR="$HOME/phone-lab/packages/api-gateway-mob"
LOG_DIR="$HOME/phone-lab/logs"
LOG_FILE="$LOG_DIR/gateway-mob.log"

sleep 30
mkdir -p "$LOG_DIR"
cd "$PKG_DIR" || exit 1

# Avoid duplicate process if boot fires twice
pgrep -f "$PKG_DIR/src/index.js" >/dev/null && exit 0

echo "$(date -Iseconds) boot: starting api-gateway-mob" >> "$LOG_FILE"
nohup "$NODE" src/index.js >> "$LOG_FILE" 2>&1 &
