#!/data/data/com.termux/files/usr/bin/bash
# Install api-content-mob boot script for Termux:Boot.
# Requires Termux:Boot app (F-Droid). Run once on phone-b-agents.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BOOT_SRC="$SCRIPT_DIR/boot-termux.sh"
BOOT_DEST="$HOME/.termux/boot/start-content-mob.sh"

if [ ! -f "$BOOT_SRC" ]; then
  echo "ERROR: boot-termux.sh not found at $BOOT_SRC"
  exit 1
fi

mkdir -p "$HOME/.termux/boot"
mkdir -p "$HOME/phone-lab/logs"
cp "$BOOT_SRC" "$BOOT_DEST"
chmod +x "$BOOT_DEST"

echo "Installed: $BOOT_DEST"
echo "Next: reboot phone-b-agents, then from dev PC run: npm run smoke:content"
