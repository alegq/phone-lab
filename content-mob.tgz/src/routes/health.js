function registerHealthRoutes(app) {
  app.get('/public/api/content/health/live', (_req, res) => {
    res.json({ status: 'alive' });
  });
}

module.exports = { registerHealthRoutes };
