function assertInternalToken(token, expected) {
  if (!expected || token !== expected) {
    const err = new Error('Invalid internal service token');
    err.statusCode = 401;
    throw err;
  }
}

function handleAuthError(res, err) {
  if (err.statusCode === 401) {
    return res.status(401).json({
      message: 'Invalid internal service token',
      statusCode: 401,
    });
  }
  throw err;
}

module.exports = { assertInternalToken, handleAuthError };
