const os = require('os');

function registerMobRoutes(app, { serviceName, deviceLabel, mobVersion, startedAt }) {
  app.get('/public/api/content/mob/ping', (req, res) => {
    res.json({
      ok: true,
      service: serviceName,
      message: 'pong from content',
      host: os.hostname(),
      deviceLabel,
      timestamp: new Date().toISOString(),
      version: mobVersion,
      remoteIp: req.ip,
    });
  });

  app.get('/public/api/content/mob/info', (_req, res) => {
    res.json({
      service: serviceName,
      version: mobVersion,
      deviceLabel,
      host: os.hostname(),
      uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
      startedAt: new Date(startedAt).toISOString(),
    });
  });
}

module.exports = { registerMobRoutes };
