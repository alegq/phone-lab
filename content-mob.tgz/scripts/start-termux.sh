#!/data/data/com.termux/files/usr/bin/bash
# Start api-content-mob from Termux (phone-b-agents).
cd "$(dirname "$0")/.." || exit 1
exec node src/index.js
