#!/data/data/com.termux/files/usr/bin/bash
# Termux:Boot — start api-content-mob after device reboot (phone-b-agents).
# Installed via: bash scripts/install-boot.sh
# Logs: ~/phone-lab/logs/content-mob.log

NODE="/data/data/com.termux/files/usr/bin/node"
PKG_DIR="$HOME/phone-lab/packages/api-content-mob"
LOG_DIR="$HOME/phone-lab/logs"
LOG_FILE="$LOG_DIR/content-mob.log"

sleep 30
mkdir -p "$LOG_DIR"
cd "$PKG_DIR" || exit 1

pgrep -f "$PKG_DIR/src/index.js" >/dev/null && exit 0

echo "$(date -Iseconds) boot: starting api-content-mob" >> "$LOG_FILE"
nohup "$NODE" src/index.js >> "$LOG_FILE" 2>&1 &
