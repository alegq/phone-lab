const express = require('express');
const os = require('os');
require('dotenv').config();

const app = express();
const PORT = Number(process.env.PORT) || 4010;
const HOST = process.env.HOST || '0.0.0.0';
const DEVICE_LABEL = process.env.DEVICE_LABEL || 'unknown';
const MOB_VERSION = process.env.MOB_VERSION || '0.1.0';
const SERVICE_NAME = 'api-agents-mob';

const startedAt = Date.now();

app.set('trust proxy', true);

app.use((req, res, next) => {
  const remote = req.ip || req.socket.remoteAddress || '-';
  console.log(`${new Date().toISOString()} ${req.method} ${req.path} remote=${remote}`);
  next();
});

app.get('/public/api/agents/mob/ping', (req, res) => {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    message: 'pong from agents',
    host: os.hostname(),
    deviceLabel: DEVICE_LABEL,
    timestamp: new Date().toISOString(),
    version: MOB_VERSION,
    remoteIp: req.ip,
  });
});

app.get('/public/api/agents/health/live', (_req, res) => {
  res.json({ status: 'alive' });
});

app.get('/public/api/agents/mob/info', (_req, res) => {
  res.json({
    service: SERVICE_NAME,
    version: MOB_VERSION,
    deviceLabel: DEVICE_LABEL,
    host: os.hostname(),
    uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
    startedAt: new Date(startedAt).toISOString(),
  });
});

app.use((_req, res) => {
  res.status(404).json({ ok: false, error: 'not_found' });
});

app.listen(PORT, HOST, () => {
  console.log(`${SERVICE_NAME} listening on ${HOST}:${PORT} label=${DEVICE_LABEL}`);
});
